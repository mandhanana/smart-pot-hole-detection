DigitalAccelerometer_MMA7660FC
==============================

Seeedstudio, Grove - 3-Axis Digital Accelerometer(±1.5g)  http://www.seeedstudio.com/depot/twig-3axis-accelerometer-p-765.html?cPath=144_146




[![Analytics](https://ga-beacon.appspot.com/UA-46589105-3/DigitalAccelerometer_MMA7660FC)](https://github.com/igrigorik/ga-beacon)
